package simulator.model;

public enum Diet {
    CARNIVORE, HERBIVORE
}