package simulator.model;

public interface Entity {
    void update(double dt);
}
