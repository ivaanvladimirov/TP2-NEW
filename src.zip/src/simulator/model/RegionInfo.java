package simulator.model;

public interface RegionInfo extends JSONable {
}
